package com.revature.model;

public class Outfit {
	public void wear() {
		System.out.println("I look fantastic");
	}
}
