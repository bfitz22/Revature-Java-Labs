package com.Brian.interfaces;

import com.Brian.model.Package;

public interface Packager {
	public Package assemblePackage();
}
